const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const { httpMethod, body } = event;
    const response = {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        body: ''
    };

    if (httpMethod === 'POST') {
        const { PostID, content } = JSON.parse(body);

        const params = {
            TableName: 'Posts',
            Item: {
                PostID: `${Date.now()}`,
                content,
                createdAt: new Date().toISOString()
            }
        };

        try {
            await docClient.put(params).promise();
            response.body = JSON.stringify({ message: 'Post created successfully' });
            console.log('Post created successfully:', params);
        } catch (err) {
            console.error('Error creating post:', err);
            response.statusCode = 500;
            response.body = JSON.stringify({ error: 'Could not create post' });
        }
    } else if (httpMethod === 'GET') {
        const params = {
            TableName: 'Posts'
        };

        try {
            const data = await docClient.scan(params).promise();
            response.body = JSON.stringify(data.Items);
            console.log('Fetched posts:', data.Items);
        } catch (err) {
            console.error('Error fetching posts:', err);
            response.statusCode = 500;
            response.body = JSON.stringify({ error: 'Could not fetch posts' });
        }
    } else {
        response.statusCode = 405;
        response.body = JSON.stringify({ error: 'Method Not Allowed' });
    }

    return response;
};
