document.addEventListener('DOMContentLoaded', () => {
    const authorizeButton = document.getElementById('authorizeButton');
    const tweetHistory = document.getElementById('tweetHistory');
    const pagination = document.getElementById('pagination');
    const baseUrl = 'http://twitter-post-env-1.eba-memqy7i5.us-east-2.elasticbeanstalk.com';

    authorizeButton.addEventListener('click', () => {
        // Redirect for OAuth authorization
        window.location.href = `${baseUrl}/authorize`;
    });

    const fetchTweetHistory = async (lastKey = '') => {
        try {
            tweetHistory.innerHTML = '<p>Loading tweet history...</p>'; // Show loading text

            const response = await fetch(`${baseUrl}/history?lastKey=${encodeURIComponent(lastKey)}`);

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            const html = await response.text();
            const data = JSON.parse(html);

            tweetHistory.innerHTML = data.html;

            // Handle pagination
            pagination.innerHTML = '';
            if (data.nextKey) {
                const nextPageButton = document.createElement('a');
                nextPageButton.textContent = 'Next Page';
                nextPageButton.href = '#';
                nextPageButton.className = 'pagination-button';
                nextPageButton.dataset.nextKey = data.nextKey;

                pagination.appendChild(nextPageButton);
            }
        } catch (error) {
            console.error('Error fetching tweet history:', error);
            tweetHistory.innerHTML = '<p>Failed to load tweet history.</p>';
        }
    };

    // Fetch initial tweet history
    const queryParams = new URLSearchParams(window.location.search);
    const lastKey = queryParams.get('lastKey');
    fetchTweetHistory(lastKey);

    // Handle pagination
    document.addEventListener('click', (event) => {
        if (event.target && event.target.classList.contains('pagination-button')) {
            const nextKey = event.target.dataset.nextKey;
            fetchTweetHistory(nextKey);
        }
    });
});






