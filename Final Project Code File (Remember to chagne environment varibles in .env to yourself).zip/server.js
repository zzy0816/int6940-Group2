const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const crypto = require('crypto');
const { URLSearchParams } = require('url');
const { TwitterApi } = require('twitter-api-v2');
const axios = require('axios');
const AWS = require('aws-sdk');
const serverless = require('serverless-http');

const app = express();

// Twitter API 配置
const client_id = process.env.TWITTER_CLIENT_ID;
const client_secret = process.env.TWITTER_CLIENT_SECRET;
const redirect_uri = process.env.REDIRECT_URI || 'http://localhost:3000/callback';

// AWS SDK 配置
AWS.config.update({
    region: process.env.AWS_REGION || 'us-east-2',
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
});

const docClient = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = 'Posts';

// 使用 express-session 中间件
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true
}));

app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }));

// 生成 code_verifier 和 code_challenge
function generateCodeVerifier() {
    return crypto.randomBytes(32).toString('hex');
}

function generateCodeChallenge(codeVerifier) {
    return crypto.createHash('sha256')
        .update(codeVerifier)
        .digest('base64')
        .replace(/\+/g, '-') // Convert '+' to '-'
        .replace(/\//g, '_') // Convert '/' to '_'
        .replace(/=+$/, ''); // Remove trailing '='
}

// 引导用户授权
app.get('/authorize', (req, res) => {
    const state = 'someRandomState';
    const codeVerifier = generateCodeVerifier();
    const codeChallenge = generateCodeChallenge(codeVerifier);

    req.session.codeVerifier = codeVerifier; // Save code_verifier in session

    const authUrl = `https://twitter.com/i/oauth2/authorize?response_type=code&client_id=${client_id}&redirect_uri=${encodeURIComponent(redirect_uri)}&state=${state}&scope=tweet.read%20tweet.write%20users.read%20follows.read%20follows.write&code_challenge=${codeChallenge}&code_challenge_method=S256`;

    res.redirect(authUrl);
});

// 处理回调并交换访问令牌
app.get('/callback', async (req, res) => {
    const code = req.query.code;
    const codeVerifier = req.session.codeVerifier;

    if (!codeVerifier) {
        return res.status(400).send('No code verifier found in session');
    }

    try {
        const tokenUrl = 'https://api.twitter.com/2/oauth2/token';
        const params = new URLSearchParams();
        params.append('grant_type', 'authorization_code');
        params.append('code', code);
        params.append('redirect_uri', redirect_uri);
        params.append('client_id', client_id);
        params.append('client_secret', client_secret);
        params.append('code_verifier', codeVerifier);

        const response = await axios.post(tokenUrl, params, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        });

        const { access_token } = response.data;
        res.redirect(`/tweet?token=${access_token}`);
    } catch (error) {
        res.status(500).send('Error exchanging code for token: ' + (error.response ? JSON.stringify(error.response.data) : error.message));
    }
});

// 显示发布推文的表单
app.get('/tweet', (req, res) => {
    const token = req.query.token;
    if (token) {
        res.send(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Post a Tweet</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                        background-color: #f4f4f4;
                        zoom: 1.5;
                    }
                    .container {
                        text-align: center;
                        padding: 30px;
                        background-color: white;
                        border-radius: 8px;
                        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
                        max-width: 900px;
                        margin: auto;
                    }
                    textarea {
                        width: 100%;
                        height: 150px;
                        padding: 15px;
                        border-radius: 8px;
                        border: 1.5px solid #ddd;
                        margin-bottom: 15px;
                        box-sizing: border-box;
                        font-size: 18px; /* 设置字体大小 */
                    }
                    button.btn {
                        background-color: #1da1f2;
                        color: white;
                        border: none;
                        padding: 15px 30px;
                        border-radius: 3px;
                        cursor: pointer;
                        font-size: 24px;
                    }
                    button.btn:hover {
                        background-color: #1991db;
                    }
                    h1, h2 {
                        margin-bottom: 30px;
                    }
                    #responseMessage {
                        margin-top: 30px;
                    }
                    a.btn {
                        display: inline-block;
                        background-color: #1da1f2;
                        color: white;
                        text-decoration: none;
                        padding: 15px 30px;
                        border-radius: 8px;
                        margin: 7.5px;
                        font-size: 24px;
                    }
                    a.btn:hover {
                        background-color: #1991db;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Post a Tweet</h1>
                    <form id="tweetForm">
                        <input type="hidden" id="token" name="token" value="${token}">
                        <textarea id="status" name="status" placeholder="Enter tweet content" required></textarea><br>
                        <button type="submit" class="btn">Post Tweet</button>
                    </form>
                    <div id="responseMessage"></div>
                    <a href="/history?token=${token}" class="btn">View Tweet History</a>
                </div>
                <script>
                    document.addEventListener('DOMContentLoaded', function () {
                        const tweetForm = document.getElementById('tweetForm');
                        const responseMessage = document.getElementById('responseMessage');
                        tweetForm.addEventListener('submit', function (event) {
                            event.preventDefault();
                            const status = document.getElementById('status').value;
                            const token = document.getElementById('token').value;
                            fetch('/postTweet', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded'
                                },
                                body: new URLSearchParams({
                                    token: token,
                                    status: status
                                })
                            })
                            .then(response => response.text())
                            .then(html => {
                                responseMessage.innerHTML = html;
                            })
                            .catch(error => {
                                console.error('Error posting tweet:', error);
                                responseMessage.innerHTML = 'Failed to post tweet.';
                            });
                        });
                    });
                </script>
            </body>
            </html>
        `);
    } else {
        res.status(400).send('No token provided');
    }
});

// 使用访问令牌发布推文并存储到 DynamoDB
app.post('/postTweet', async (req, res) => {
    const { token, status } = req.body;

    try {
        const client = new TwitterApi(token);
        const { data } = await client.v2.tweet(status);

        const params = {
            TableName: TABLE_NAME,
            Item: {
                PostID: `${Date.now()}`,
                Content: status,
                TwitterID: data.id
            }
        };

        await docClient.put(params).promise();

        // 使用 HTML 模板动态生成内容，并内嵌 CSS
        res.send(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Tweet Posted</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                        background-color: #f4f4f4;
                        zoom: 1.5;
                    }
                    .container {
                        text-align: center;
                        padding: 20px;
                        background-color: white;
                        border-radius: 8px;
                        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
                        max-width: 900px;
                        margin: auto;
                    }
                    blockquote {
                        border-left: 3px solid #1da1f2;
                        padding-left: 30px;
                        margin: 30px 0;
                        font-style: italic;
                        color: #333;
                        font-size: 18px; /* 设置字体大小 */
                    }
                    a.btn {
                        display: inline-block;
                        background-color: #1da1f2;
                        color: white;
                        text-decoration: none;
                        padding: 15px 30px;
                        border-radius: 8px;
                        margin: 7.5px;
                        font-size: 24px;
                    }
                    a.btn:hover {
                        background-color: #1991db;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Tweet Posted Successfully</h1>
                    <p>Your tweet:</p>
                    <blockquote>${status}</blockquote>
                    <a href="/tweet?token=${token}" class="btn">Post a New Tweet</a>
                    <a href="javascript:history.back()" class="btn">Return to Previous Page</a>
                </div>
            </body>
            </html>
        `);
    } catch (error) {
        console.error('Error posting tweet:', error);
        res.status(500).send('Error posting tweet: ' + (error.response ? JSON.stringify(error.response.data) : error.message));
    }
});

// 显示所有推文（分页并按时间顺序排序）
app.get('/history', async (req, res) => {
    const limit = 20; // 每页条数
    const lastKey = req.query.lastKey; // 用于分页的最后一条记录的键

    const params = {
        TableName: TABLE_NAME,
        Limit: limit + 1, // 取多一条数据，以确定是否有下一页
        ScanIndexForward: false // 降序排列
    };

    if (lastKey) {
        params.ExclusiveStartKey = JSON.parse(lastKey); // 使用上一个分页的最后一条记录
    }

    try {
        const data = await docClient.scan(params).promise();
        const items = data.Items;
        const hasMore = items.length > limit;

        if (hasMore) {
            items.pop(); // 移除多出来的那一条记录
        }

        res.send(`
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Tweet History</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        display: flex;
                        justify-content: center;
                        align-items: center;
                        height: 100vh;
                        margin: 0;
                        background-color: #f4f4f4;
                        zoom: 1.5;
                    }
                    .container {
                        text-align: center;
                        padding: 30px;
                        background-color: white;
                        border-radius: 8px;
                        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
                        max-width: 900px;
                        margin: auto;
                    }
                    ul {
                        list-style: none;
                        padding: 0;
                        font-size: 18px; /* 设置字体大小 */
                    }
                    li {
                        padding: 15px;
                        border-bottom: 1.5px solid #ddd;
                        margin: 7.5px 0;
                    }
                    a.btn {
                        display: inline-block;
                        background-color: #1da1f2;
                        color: white;
                        text-decoration: none;
                        padding: 15px 30px;
                        border-radius: 8px;
                        margin: 7.5px;
                        font-size: 24px;
                    }
                    a.btn:hover {
                        background-color: #1991db;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <h1>Tweet History</h1>
                    <ul>
                        ${items.map(item => `<li>${item.Content}</li>`).join('')}
                    </ul>
                    ${hasMore ? `<a href="/history?lastKey=${encodeURIComponent(JSON.stringify(items[items.length - 1]))}" class="btn">Next Page</a>` : ''}
                    <a href="javascript:history.back()" class="btn">Return to Previous Page</a>
                </div>
            </body>
            </html>
        `);
    } catch (error) {
        console.error('Error fetching tweet history:', error);
        res.status(500).send('Error fetching tweet history: ' + (error.response ? JSON.stringify(error.response.data) : error.message));
    }
});

// 监听端口
const PORT = process.env.PORT || 8080; // 默认端口是 8080
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

// 将 express app 包装成 Lambda 处理程序
module.exports.handler = serverless(app);
